#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "../Include/util.h"
#include "../Include/list.h"
#include "../Include/tree.h"
#include "../Include/heap.h"
#include "../Include/sort.h"
#include "../Include/geometry.h"
#include "../Include/algo.h"

#include <stdbool.h>

/**
 * @brief Réalise la lecture d'un ensemble des points à partir du fichier
 * \p filename.
 * Renvoie 2 paramètres : un tableau contenant les points du fichier
 * \p filename, le nombre \p N de ces points.
 *
 * @param[in] filename le nom du fichier qui contient les points d'entrée.
 * @param[out] N le nombre des points dans le fichier \p filename
 * (paramètre de sortie).
 * @return Point** le tableau avec les points du fichier \p filename.
 */
static Point** readInstance(const char* filename, int* N) {
    // Ouverture du fichier (MODE lecture)
    FILE * Fichier = fopen(filename, "rt");
    assert(Fichier);

    // Récuperation du nb de points présent dans le fichier
    fscanf(Fichier, "%d", N);
    assert(*N > 0);

    // Création de notre tableau de pointeurs de type Point
    Point** TableauPointsFichier = malloc(*N * sizeof(Point*));
    assert(TableauPointsFichier);


    // Récupération des points + Ajout dans le tableau
    for (int i = 0; i < *N; i++) {
        long long int x,y;
        fscanf(Fichier, "%lld", &x);
        fscanf(Fichier, "%lld", &y);
        Point* PointFichier = newPoint(x,y);
        TableauPointsFichier[i] = PointFichier;
    }

    fclose(Fichier);
    return TableauPointsFichier;
}

/**
 * @brief Réalise l'écriture de l'ensemble des points de la liste \p L
 * dans un fichier avec le nom \p filename.
 *
 * @param[in] filename le nom du fichier d'écriture.
 * @param[in] L la liste des points à écrire dans le fichier \p filename.
 */
static void writeSolution(const char* filename, List* L) {
    assert(L);

    // Ouverture du fichier (MODE écriture)
    FILE * Fichier = fopen(filename, "wt");
    assert(Fichier);

    fprintf(Fichier, "%d\n", L->numelm);
    for (LNode* E = L->head; E; E = E->succ) {
       Point* pointFichier = (Point*)E->data;
       assert(pointFichier);
       fprintf(Fichier, "%lld %lld\n", pointFichier->x, pointFichier->y);
    }

    fclose(Fichier);
}

/**
 * @brief Compare le points \p a et \p b.
 *
 * @param[in] a
 * @param[in] b
 * @return int si l'abscisse de \p a est plus petite que l'abscisse de \p b
 * renvoie 1, sinon renvoie 0. Dans le cas d'égalité, si l'ordonnée de \p a
 * est plus petite que l'ordonnée de \p b renvoie 1, sinon renvoie 0.
 */
static int smallerPoint(const void* a, const void* b) {
 assert(a);
 assert(b);

 Point* PointA = (Point*)a;
 Point* PointB = (Point*)b;

 if (PointA->x < PointB->x) {
  return 1;
 }
 else {
  if (PointA->x == PointB->x && PointA->y < PointB->y) {
   return 1;
  }
  else {
   return 0;
  }
 }
}

//---------- MODULES SlowConvexeHull ----------
/**
 * Méthode 1 : RecupData (Retourne un tableau de points contenant tous les points du fichier d'entrée)
 * Méthode 2: initListDedges (Retourne une liste contenant les arêtes de notre enveloppe convexe)
 * Méthode 3 : suppressionMemoireVariablesTemporairesSlow (Supprime en mémoire les variables passées en paramètre)
 */

//---------- MODULES DedgesToClockwisePoints ----------
/**
 * Méthode 1 : ConversionListeArcsEnListePoints (Retourne une liste de points à partir d'une liste d'arcs qui lui est passée en paramètre)
 * Méthode 2 : CorrigerSensHorairePolygone (Retourne la liste de points passées en paramètre celle-ci est corrigée si ses points sont dans le sens Anti-Horaire)
 */

List* ConversionListeArcsEnListePoints(List* dedges){
    /* La gestion des cas particuliers est réalisée dans le SlowConvexeHull*/
    /**
     * Initialisation de nos variables de départ : 
     * pointDepart -> Point d'ouverture et de fermeture de notre enveloppe convexe 
     * pointDestination -> Point qui succède pointDepart 
     */
    List* ListPoints = newList(viewPoint, freePoint);
    Point* pointDepart = getOrigin((DEdge*) dedges->head->data);
    Point* pointDestination = getDestination((DEdge*) dedges->head->data);

    /**
     * Le code ci-dessous permet d'ajouter tous les autres points se trouvant dans la liste d'arcs dedges 
     * On ajoute pointDestination à la liste TANT QUE celui-ci n'est pas égal à pointDepart (puisque pointDepart est également le point de fermeture de notre enveloppe)
     * Exemple : 
     * Dedges(ArcsNonOrdonnés) = (Pa, Pc)(Pd, Pa)(Pc, Pe)(Pe, Pd)
     * (ite1) pointDestination = Pc -> (AJOUT)
     * (ite2) pointDestination = Pe -> (AJOUT)
     * (ite3) pointDestination = Pd -> (AJOUT)
     * (ite4) pointDestination = Pa (FIN)(pointDepart == pointDestination)
     */
    listInsertLast(ListPoints, pointDepart);
    while (pointDepart != pointDestination){
        listInsertLast(ListPoints, pointDestination);

        Point* pointTrv = NULL;
        for (LNode* E = dedges->head; E; E = E->succ) {

            if (getOrigin((DEdge*) E->data) == pointDestination) {
                pointTrv = getDestination((DEdge*) E->data);
                break;
            }

        }
        assert(pointTrv); 
        pointDestination = pointTrv; 
    }
    return ListPoints; 
}

List* CorrigerSensHorairePolygone(List* ListPoints){
    /* La gestion des cas particuliers est réalisée dans le SlowConvexeHull*/
    /**
     * Pour vérifier si les points de la liste passée en paramètre sont bien dans le sens horaire nous allons appliquer 
     * la méthode des lactes de souliers 
     * 
     * Exemple et représentation de la méthode : 
     * 
     * Hypothèses de départ 
     * ListPoints (P1(-4;2), P2(0;3), P3(4;3), P4(1;-4))
     * 2 sens possibles --> (Anti-Horaire)(P1, P4, P3, P2, P1) (Horaire)(P1, P2, P3, P4, P1)
     * 
     * Les points doivent être disposés dans l'ordre dans lequel ils se trouvent dans la liste de points (Anti-Horaire ou Horaire)
     * (On prend l'exemple du sens horaire)
     * -4    2 (P1)
     *  0    3 (P2)
     *  4    3 (P3)     Aire polygone = (-4 * 3)(0 * 3)(4 * -4)(1 *2) - (0 * 2)(4 * 3)(1 * 3)(-4 * -4)  
     *  1   -4 (P4)
     * -4    2 (P1)
     * 
     * Si (Aire polygone < 0) Alors (Sens Horaire)
     * Si (Aire polygone > 0) Alors (Sens Anti-Horaire)
     */

    /**
     * On récuppère le premier noeud de la liste dans une variable car l'enveloppe doit se fermer sur ce meme point
     * On considère en réalité que le premier point est également le dernier  
     */
    long long int AirePolygone = 0; 
    LNode* PremierNoeudList = ListPoints->head;

    /* Calcul de l'aire du polygone */
    for (LNode* n = ListPoints->head; n; n = n->succ) {
        Point* PointCourant = (Point*)n->data;
        Point* PointSuivant;

        if (n->succ) {
            PointSuivant = (Point*)n->succ->data;
        }
        else {
            PointSuivant = (Point*)PremierNoeudList->data;
        }

        AirePolygone += (PointCourant->x * PointSuivant->y)
        - (PointSuivant->x * PointCourant->y);       
    }

    /* Correction du sens Anti-Horaire */
    if (AirePolygone > 0) {
        List* ListCorrigee = newList(ListPoints->viewData, ListPoints->freeData);

        for (LNode* n = ListPoints->head->succ; n; n = n->succ) {
            listInsertFirst(ListCorrigee, n->data);
        }

        listInsertFirst(ListCorrigee, PremierNoeudList->data); 
        freeList(ListPoints, 0);
        ListPoints = ListCorrigee;
    }

    return ListPoints;
}



/**
 * @brief Transforme la liste des arcs \p dedges décrivant les arêtes
 * du polygone de l'enveloppe convexe à une liste des poins ordonnés
 * dans le sens horaire.
 *
 * @param[in] edges la liste des arcs de l'enveloppe convexe
 * @return List* la liste des points de l'enveloppe convexe dans le sens
 * horaire
 */
static List * DedgesToClockwisePoints(List* dedges) {
    /**
     * Conversion de la liste dedges en une liste de points
     * ATTENTION -> On ne sait pas si la liste est dans le sens horaire ou anti-horaire
     *  */ 
    List* ListPoints = ConversionListeArcsEnListePoints(dedges); 
    assert(ListPoints); 

    /**
     * Vérification et correction de la liste de points (si les points sont disposés dans le sens Anti-Horaire)
     */
    ListPoints = CorrigerSensHorairePolygone(ListPoints); 

    return ListPoints; 
}


Point** RecupData(const char* infilename, int* NbPoints){
    // Grâce à readInstance on retourne un tableau de points ET on initialise la variable NbPoints 
    return readInstance(infilename, NbPoints); 
}

List* initListDedges(Point** tableauPoints, int nbPoints){
    /**
     * L'objectif de cette fonction est de déterminer quels sont les points contenus dans tableauPoints qui appartiennent 
     * à l'enveloppe convexe de notre polygone
     * 
     * Etape 1 : Nous devons tester toutes les combinaisons de points possibles en tant qu'arete
     * Etape 2 : Chaque arete créée sera alors testée avec tous les autres points 
     * 
     * Si (nouvelleAreteCréée n'a aucun point à sa droite ET ne passe par aucun point) Alors (ajouter l'rrete (DEdge) à la liste) 
     * Sinon (l'arete n'appartient pas à l'enveloppe convexe de notre polygone)
     */


    /* Création de la liste qui devra contenir l'ensemble des arretes de notre polygone */ 
    List* listAretesEnveloppe = newList(viewDEdge, freeDEdge);

    /* Rappel (DEdge -> arrête contenant un point d'origine et un point destination)*/
    
    // Boucle permettant de tester l'ensemble des points d'origine 
    for (int i = 0; i < nbPoints; i++) {
        // Boucle permettant de tester l'ensemble des points destination
        for (int j = 0; j < nbPoints; j++) {
            
            if (i != j) {
                bool estValide = true; 

                // Boucle permettant de tester l'ensemble des points sur notre nouvelleAreteCréée (tableauPoints[i] --> tableauPoints[j])
                for (int k = 0; k < nbPoints; k++){
                    
                    if (i != k && j != k) {
                        if (onLeft(tableauPoints[i], tableauPoints[j], tableauPoints[k]) || isIncluded(tableauPoints[i], tableauPoints[j], tableauPoints[k])) {
                            estValide = false;
                            break; 
                        }
                    }

                }

                /* Si (estValide n'a pas été modifié) alors (l'arrête appartient à l'enveloppe convexe) */
                if (estValide) {
                    DEdge* AretePoly = newDEdge(tableauPoints[i], tableauPoints[j]);
                    listInsertLast(listAretesEnveloppe, AretePoly);
                }
            }

        }

    }

    return listAretesEnveloppe; 

}


void suppressionMemoireVariablesTemporairesSlow(Point** tableauPoints, int nbPoints, List* listAretesEnveloppe, List* listPoints) {
    /* Libération en mémoire de l'ensemble des paramètres de notre procédure */
    for (int i = 0; i < nbPoints; i++) {
    freePoint(tableauPoints[i]);
   }
   free(tableauPoints);

   
   freeList(listAretesEnveloppe, 1);

   
   freeList(listPoints, 0);
}


void SlowConvexHull(const char* infilename, const char* outfilename) {
    /* Le contrôle des fichiers passés en paramètre est réalisé dans writeSolution et readInstance */
    
    /* Récupérations des points du le fichier d'entrée + stockage du nombre de points dans une variable */
    int nbPoints; 
    Point** tableauPoints = RecupData(infilename, &nbPoints); 

    /**
     * Puisqu'une enveloppe convexe doit être consistuée d'un minimum de 3 points nous avons décidés de stopper l'execution de notre programme
     * si nbPoints ne respecte pas cette condition 
     */
    assert(nbPoints >= 3); 

    /* Création d'une liste contenant les arcs/aretes de notre enveloppe convexe*/
    List* listAretesEnveloppe = initListDedges(tableauPoints, nbPoints);

    /* Conversion de notre liste d'aretes en une liste de points triés dans le sens Horaire*/
    List* listPoints = DedgesToClockwisePoints(listAretesEnveloppe); 

    /* Report de notre liste de points dans le fichier de sortie */
    writeSolution(outfilename, listPoints); 

    /* Suppression mémoire des structures temporaires */
    suppressionMemoireVariablesTemporairesSlow(tableauPoints, nbPoints, listAretesEnveloppe, listPoints); 
}



/**
 * @brief Compare le points \p a et \p b.
 *
 * @param[in] a
 * @param[in] b
 * @return int si l'abscisse de \p a est plus grande que l'abscisse de \p b
 * renvoie 1, sinon renvoie 0. Dans le cas d'égalité, si l'ordonnée de \p a
 * est plus grande que l'ordonnée de \p b renvoie 1, sinon renvoie 0.
 */
static int biggerPoint(const void* a, const void* b) {
	assert(a);
    assert(b);

    Point* PointA = (Point*)a;
    Point* PointB = (Point*)b;

    if (PointA->x > PointB->x) {
        return 1;
    }

    if (PointA->x == PointB->x && PointA->y > PointB->y) {
        return 1;
    }
    return 0;
}


//---------- MODULES ConvexeHull ----------
/**
 * Méthode 1 : RecupData (Retourne un tableau de points contenant tous les points du fichier d'entrée) (Voir Modules SloxConvexeHull)
 * Méthode 2 : Hsup (Retourne une liste de points représentant l'enveloppe convexe supérieure)
 * Méthode 3 : Hinf (Retourne une liste de points représentant l'enveloppe convexe inférieure)
 * Méthode 4 : SortTabPoints (Tri le tableau de points passé en paramètre en utilisant un algorithme de tri spécifique à la valeur de sortby)
 * Méthode 5 : suppressionMemoireVariablesTemporairesNormal (Suppression en mémoire des variables passées en paramètre)
 */


List* Hsup(Point** TableauPointsTrie, int nbPoints) {
    /**
     * L'objectif de cette fonction est de retourner une liste de points contenant l'enveloppe convexe supérieure de notre polygone 
     * 
     * Propriété
     * -> Les points appartenant à l'enveloppe supérieure ont pour propriété d'avoir des ordonnées supérieures à 
     *    celles des points ayant la plus grande et la plus petite abscisse de l'enveloppe convexe
     * 
     * ATTENTION le tableau contenant tous les points de notre fichier d'entrée doit être trié dans l'ordre croissant
     * 
     * Principe de la méthode : 
     * (1) Création d'une liste contenant les 2 points ayant les plus petites abscisses 
     * (2) Parcours de l'ensemble des points restant : 
     *     - Ajout d'un nouveau point à la liste 
     *     - Tant que (la liste contient plus de deux éléments ET                                                                                                       
     *       que le dernier point ajouté se trouve à gauche de l'arete (pointOrigine : AvantAvantDernierPointListe; pointDestination : AvantDernierPointListe)) Faire
     *          Supprimer AvantDernierPointListe 
     * 
     */


    /* La gestion des cas particuliers (nbPoints < 3) est réalisée dans le ConvexeHull */

    /* Initilisation de la liste et des 2 premiers points à ajouter (Principe méthode (1))*/ 
    List* ListPointsEnveloppeSup = newList(viewPoint, freePoint); 

    listInsertLast(ListPointsEnveloppeSup, TableauPointsTrie[0]);
    listInsertLast(ListPointsEnveloppeSup, TableauPointsTrie[1]);

    /* Parcours des points restant dans le tableau de points (Principe méthode (2))*/
    for (int i = 2; i < nbPoints; i++){ 
        listInsertLast(ListPointsEnveloppeSup, TableauPointsTrie[i]);

        while (ListPointsEnveloppeSup->numelm > 2) {

            Point* DernierPoint = ListPointsEnveloppeSup->tail->data;
            LNode* NoeudAvantDernierPoint = ListPointsEnveloppeSup->tail->pred;
            Point* AvantDernierPoint = ListPointsEnveloppeSup->tail->pred->data;
            Point* AvantAvantDernierPoint = ListPointsEnveloppeSup->tail->pred->pred->data;

            if (onLeft(AvantAvantDernierPoint, AvantDernierPoint, DernierPoint)){
                listRemoveNode(ListPointsEnveloppeSup, NoeudAvantDernierPoint);
            }
            else {
                break;
            }

        }
    }

    return ListPointsEnveloppeSup; 

}

List* Hinf(Point** TableauPointsTrie, int nbPoints) {
    /**
     * L'objectif de cette fonction est de retourner une liste de points contenant l'enveloppe convexe inférieure de notre polygone 
     * 
     * Propriété
     * -> Les points appartenant à l'enveloppe inférieure ont pour propriété d'avoir des ordonnées inférieures à 
     *    celles des points ayant la plus grande et la plus petite abscisse de l'enveloppe convexe
     * 
     * ATTENTION le tableau contenant tous les points de notre fichier d'entrée doit être trié dans l'ordre croissant
     * 
     * Principe de la méthode : 
     * (1) Création d'une liste contenant les 2 points ayant les plus grandes abscisses 
     * (2) Parcours de l'ensemble des points restant :  (ATTENTION Cette fois-ci on parcours notre tableau de points dans le sens décroissant)
     *     - Ajout d'un nouveau point à la liste 
     *     - Tant que (la liste contient plus de deux éléments ET                                                                                                       
     *       que le dernier point ajouté se trouve à gauche de l'arete (pointOrigine : AvantAvantDernierPointListe; pointDestination : AvantDernierPointListe)) Faire
     *          Supprimer AvantDernierPointListe 
     * 
     */

    /* La gestion des cas particuliers (nbPoints < 3) est réalisée dans le ConvexeHull */

    /* Initilisation de la liste et des 2 derniers points à ajouter (Principe méthode (1))*/ 
    List* ListPointsEnveloppeInf = newList(viewPoint, freePoint);

    listInsertLast(ListPointsEnveloppeInf, TableauPointsTrie[nbPoints-1]);
    listInsertLast(ListPointsEnveloppeInf, TableauPointsTrie[nbPoints-2]);

    /* Parcours des points restant dans le tableau de points (Principe méthode (2))*/
    for (int i = nbPoints-3; i >= 0; i--) {
        listInsertLast(ListPointsEnveloppeInf, TableauPointsTrie[i]);

        while (ListPointsEnveloppeInf->numelm > 2) {

            Point* DernierPoint = ListPointsEnveloppeInf->tail->data;
            LNode* NoeudAvantDernierPoint = ListPointsEnveloppeInf->tail->pred;
            Point* AvantDernierPoint = ListPointsEnveloppeInf->tail->pred->data;
            Point* AvantAvantDernierPoint = ListPointsEnveloppeInf->tail->pred->pred->data;

            if (onLeft(AvantAvantDernierPoint, AvantDernierPoint, DernierPoint)) {
                listRemoveNode(ListPointsEnveloppeInf, NoeudAvantDernierPoint);
            }
            else {
                break;
            }
        }
    }

    return ListPointsEnveloppeInf; 

}

void SortTabPoints(Point** tableauPoints, int nbPoints, int sortby) {
    /**
     * Cette procédure tri le tableau de points passés en paramètre dans l'ordre croissant
     * La méthode de tri utilisée dépend de la valeur de sortby (ATTENTION sortby ne peut prendre que 3 valeurs)
     * sortby = 1 --> tri par tas utilisant une structure arbre avec pointeurs
     * sortby = 2 --> tri par tas utilisant un tableau
     * sortby = 3 --> tri par sélection (tri par échange)
     */
    /* Les contrôles concernant les valeurs prises par sortby sont réalisés dans ConvexHull */
    if (sortby == 1) {
        CBTHeapSort((void**)tableauPoints, nbPoints, smallerPoint, viewPoint, freePoint);
    }
    else if (sortby == 2) {
        ArrayHeapSort((void**)tableauPoints, nbPoints, smallerPoint, viewPoint, freePoint);
    }
    else {
        SelectionSort((void**)tableauPoints, nbPoints, smallerPoint);
    }
}

void suppressionMemoireVariablesTemporairesNormal(Point** tableauPoints, int nbPoints, List* ListPointsEnveloppe) {
    /* Libération en mémoire de l'ensemble des paramètres de notre fonction */
    freeList(ListPointsEnveloppe, 0); 

    for (int i = 0; i < nbPoints; i++) {
        freePoint(tableauPoints[i]); 
    }
    free(tableauPoints); 
}





void ConvexHull(const char* infilename, const char* outfilename, int sortby) {
    /* Le contrôle des fichiers passés en paramètre est réalisé dans writeSolution et readInstance */

    /* Récupérations des points du le fichier d'entrée + stockage du nombre de points dans une variable */
    int nbPoints;
    Point** tableauPoints = RecupData(infilename, &nbPoints);
    
    /**
     * Puisqu'une enveloppe convexe doit être consistuée d'un minimum de 3 points nous avons décidés de stopper l'execution de notre programme
     * si nbPoints ne respecte pas cette condition
     */
    assert(nbPoints >= 3);

    /**
     * Tri du tableau de points (la méthode de tri utilisée dépend de la valeur associée à sortby)
     * sortby doit appartenir à l'intervalle [1 ; 3], sinon l'exécution du programme sera arrêtée
     */
    assert(sortby >= 1 && sortby <= 3); 
    SortTabPoints(tableauPoints, nbPoints, sortby); 
    
    /**
     * Récupération de l'enveloppe supérieure et inférieure dans des listes de points
     */
    List* ListPointsHsup = Hsup(tableauPoints, nbPoints); 
    List* ListPointsHinf = Hinf(tableauPoints, nbPoints); 

    /**
     * Suppression des derniers points de chacunes des listes 
     * DernierPointHsup = PremierPointHinf
     * DenrierPointHinf = PremierPointHsup 
     */
    listRemoveLast(ListPointsHsup); 
    listRemoveLast(ListPointsHinf); 

    /* Concaténation de Hsup et Hinf pour obtenir l'enveloppe convexe dans son intégralité */
    List* ListPointsEnveloppe = listConcatenate(ListPointsHsup, ListPointsHinf); 

    /* Report de notre liste de points dans le fichier de sortie */
    writeSolution(outfilename, ListPointsEnveloppe); 

    /* Suppression mémoire des structures temporaires */
    suppressionMemoireVariablesTemporairesNormal(tableauPoints, nbPoints, ListPointsEnveloppe); 
}


//---------- MODULES RapidConvexHull ----------
/**
 * Méthode 1 : RecupData (Retourne un tableau de points contenant tous les points du fichier d'entrée) (Voir Modules SloxConvexeHull)
 * Méthode 2 : RecherchePointMinTableau (Retourne le point du tableau avec la plus abscisse)
 * Méthode 3 : AjoutPointsEnveloppeConvexMin (Retourne la liste contenant les points appartenant à l'enveloppe convexe minimale)
 * Méthode 4 : suppressionMemoireVariablesTemporairesNormal (Suppression en mémoire des variables passées en paramètre) (Voir Modules ConvexHull)
 */

Point* RecherchePointMinTableau(Point** tableauPoints, int nbPoints) {
    /**
     * Retourne le point du tableau avec la plus petite abscisse 
     * Remarque : 
     * Les cas particuliers sont gérés directement dans RapidConvexHull
     */
    
     Point* pointMin = tableauPoints[0]; 
    
    for (int i = 1; i < nbPoints; i++) {
        if (smallerPoint(tableauPoints[i], pointMin)) {
            pointMin = tableauPoints[i];
        }
    }

    return pointMin; 

}


List* AjoutPointsEnveloppeConvexMin(List* ListPoints, Point* pointMin, Point** tableauPoints, int nbPoints){
    /**
     * L'objectif de cette fonction est d'ajouter à la variable ListPoints les points appartenant à l'enveloppe convexe
     *
     * ATTENTION nous avons supposé que nous devions respecter le pseudo-code vu en cours,
     * ce qui implique une détermination de l'enveloppe convexe MINIMALE
     *
     * Principe de la méthode :
     *  Tant que (pointMin != dernierPointAjouté) Faire (<=> Faire .... Tq)
     *      (1) Récupération du dernier point ajouté à la liste (Point A)
     *      (2) Recherche d'un point candidat (pointCandidat != dernierPointAjouté) (Point B)
     *      (3) Vérification du point candidat (par un test avec tous les points du tableau différents de A et B) (Point P)
     *              Si (il n’existe aucun point P strictement à gauche du segment (A,B)
     *                  et aucun point P collinéaire au segment (A,B) plus extrême que B)
     *              Alors (le point candidat B est validé et devient le prochain point de l’enveloppe convexe)
     *
     *              Sinon (le point candidat B est remplacé par un point P plus à gauche
     *                     ou collinéaire mais plus extrême, et la vérification se poursuit)
     */
    
    
     /* Les cas particuliers sont automatiquements neutralisés par le RapideConvexHull */
    do {
        /* Récupération du dernier point ajouté à la liste (Principe de la méthode (1)) */
        Point* A = (Point*)getLNodeData(Tail(ListPoints));

        /* Recherche d'un point candidat (Principe de la méthode (2)) */
        Point* B = NULL;
        for (int i = 0; i < nbPoints; i++) {
            if (tableauPoints[i] != A) {
                B = tableauPoints[i];
                break;
            }
        }

        /* Vérification du point candidat (Principe de la méthode (3)) */
        for (int j = 0; j < nbPoints; j++) {
            Point* P = tableauPoints[j];
            if (P == B || P == A) continue;

            if (onLeft(A, B, P) || (collinear(A, B, P) && isIncluded(A, P, B))) {
                B = P; // Nouveau candidat 
            }
        }

        /* Ajout du point B ayant été vérifié */
        listInsertLast(ListPoints, B);

    } while ((Point*)getLNodeData(Tail(ListPoints)) != pointMin); 

    /* Suppression du doublon pointMin */
    listRemoveLast(ListPoints);
    
    return ListPoints; 
}



void RapidConvexHull(const char* infilename, const char* outfilename)
{
    /* Le contrôle des fichiers passés en paramètre est réalisé dans writeSolution et readInstance */

    /* Récupérations des points du le fichier d'entrée + stockage du nombre de points dans une variable */
    int nbPoints;
    Point** tableauPoints = RecupData(infilename, &nbPoints);

    /**
     * Puisqu'une enveloppe convexe doit être consistuée d'un minimum de 3 points nous avons décidés de stopper l'execution de notre programme
     * si nbPoints ne respecte pas cette condition
     */
    assert(nbPoints >= 3);

    /* Récupération du point avec la plus petite abscisse */
    Point* pointMin = RecherchePointMinTableau(tableauPoints, nbPoints); 

    /* Création d'une liste de points + ajout du point min dans la liste */
    List* ListPoints = newList(viewPoint, freePoint); 
    listInsertLast(ListPoints, pointMin);

    /* Ajout des points appartenant à l'enveloppe convexe MINIMALE */
    ListPoints = AjoutPointsEnveloppeConvexMin(ListPoints, pointMin, tableauPoints, nbPoints); 

    /* Report de notre liste de points dans le fichier de sortie */
    writeSolution(outfilename, ListPoints);

    /* Suppression mémoire des structures temporaires */
    suppressionMemoireVariablesTemporairesNormal(tableauPoints, nbPoints, ListPoints);
}
