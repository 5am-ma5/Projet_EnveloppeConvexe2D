#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "../Include/util.h"
#include "../Include/tree.h"
#include "../Include/heap.h"

/**********************************************************************************
 * ARRAY HEAP
 **********************************************************************************/

/* Renvoie la capacité maximale du tas tableau (nombre de cases allouées). */
int getAHMaxSize(const ArrayHeap* AH) {
	assert(AH); 
	return AH->MAX; 
}

/* Renvoie le nombre d'éléments actuellement présents dans le tas tableau. */
int getAHActualSize(const ArrayHeap* AH) {
	assert(AH); 
	return AH->N; 
}

/* Renvoie le pointeur data stocké à la position pos (NULL si pos invalide). */
void* getAHNodeAt(const ArrayHeap* AH, int pos) {
	assert(AH); 
	/* On n'autorise l'accès qu'aux indices effectivement utilisés [0..N-1]. */
	if (pos >= 0 && pos < getAHActualSize(AH)){
		return AH->A[pos]; 
	}
	return NULL; 
}

/* Décrémente la taille effective N du tas (sans libérer les données). */
void decreaseAHActualSize(ArrayHeap* AH) {
	assert(AH); 
	/* Sécurité : ne pas descendre en dessous de 0. */
	if (getAHActualSize(AH) > 0){
		AH->N--; 
	}
}

/* Remplace la donnée à l'indice position par newData (si position valide). */
void setAHNodeAt(ArrayHeap* AH, int position, void* newData) {
	assert(AH); 
	/* Ici on vérifie position dans [0..N-1]. On ne permet pas d'écrire au-delà de N. */
	if (position >= 0 && position < getAHActualSize(AH)){
		AH->A[position] = newData; 
	}
	else {
		/* Message d'erreur : utile en debug, mais à éviter en prod si on veut un code silencieux. */
		printf("Le remplacement de l'élément se trouvant à la position (%d) a échoué...\n", position); 
	}
}

// AJOUT DE LA PRIMITIVE ESTVIDE()
/* Teste si une position est "vide" dans le tas, i.e. hors intervalle [0..N-1]. */
int isEmpty(const ArrayHeap* AH, int position){
	assert(AH); 
	return (position < 0 || position >= getAHActualSize(AH)); 
}

// AJOUT DE LA PRIMITIVE ECHANGER()
/* Échange les pointeurs A[pos1] et A[pos2] si les deux positions sont valides. */
void Switch(ArrayHeap* AH, int pos1, int pos2){
	assert(AH); 
	if (pos1 >= 0 && pos2 >= 0 && pos1 < getAHActualSize(AH) && pos2 < getAHActualSize(AH)){
		void* tmp = AH->A[pos1]; 
		AH->A[pos1] = AH->A[pos2]; 
		AH->A[pos2] = tmp; 
	}
}


/**
 * @brief Corrige la position de l'élément de la position \p pos
 * du tas \p AH en le comparant avec ses fils et en l'échangeant avec
 * le fils de la plus grande priorité si nécessaire.
 *
 * Procédure récursive.
 * 
 * @param[in] AH 
 * @param[in] pos L'indice de la valeur en mouvement vers le bas.
 */
static void updateArrayHeapDownwards(ArrayHeap* AH, int pos) {
	assert(AH); 

	/* Si pos est hors de la zone utilisée, il n'y a rien à corriger. */
	if (isEmpty(AH, pos)){
		return; 
	}

	/* Indices des fils en représentation tableau :
	 * fils gauche = 2*pos + 1 ; fils droit = 2*pos + 2 */
	int fg = 2 * pos + 1; 
	int fd = 2 * pos + 2; 

	/* Ici la variable s'appelle "min" mais en réalité elle stocke l'indice
	 * du nœud avec la meilleure priorité selon preceed (min-heap ou priorité max
	 * selon convention de preceed). */
	int min = pos; 

	/* Si le fils gauche existe et "précède" le meilleur actuel, il devient candidat. */
	if (!isEmpty(AH, fg) && AH->preceed(AH->A[fg], AH->A[min])){
		min = fg; 
	}

	/* Même test avec le fils droit. */
	if (!isEmpty(AH, fd) && AH->preceed(AH->A[fd], AH->A[min])){
		min = fd; 
	}

	/* Si un fils a une meilleure priorité que le parent, on échange et on continue. */
	if (min != pos){
		Switch(AH, pos, min); 
		updateArrayHeapDownwards(AH, min); 
	}
}



ArrayHeap* ArrayToArrayHeap(void** A, int N,
					int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) 
{
	assert(A); 
	assert(preceed); 
	assert(viewHeapData); 
	assert(freeHeapData); 
	
	/* N négatif n'a pas de sens : on refuse. */
	if (N < 0){
		return NULL; 
	}

	/* On crée une structure de tas en s'appuyant directement sur le tableau A fourni.
	 * Important : on ne malloc pas A ici, on le "réutilise". */
	ArrayHeap* newAH = malloc(sizeof(ArrayHeap));
	assert(newAH); 
	newAH->A = A; 
	newAH->freeHeapData = freeHeapData; 
	newAH->preceed = preceed; 
	newAH->viewHeapData = viewHeapData; 
	newAH->N = N; 
	newAH->MAX = N; 

	/* Construction du tas en O(N) :
	 * on "heapify" depuis le dernier nœud interne jusqu'à la racine. */
	for (int i = (N/2)-1; i >= 0; i--){
		updateArrayHeapDownwards(newAH, i); 
	}
	return newAH; 
}

void viewArrayHeap(const ArrayHeap* AH) {
	assert(AH); 
	printf("---Affichage ArrayHeap---\n"); 
	/* Attention : affichage linéaire de A[0..N-1] (pas une visualisation en arbre). */
	for (int i = 0; i < AH->N; i++){
		AH->viewHeapData(AH->A[i]); 
	}
	printf("---Fin Affichage---\n"); 
}

void freeArrayHeap(ArrayHeap* AH, int deletedata) {
	assert(deletedata == 0 || deletedata == 1); 
	if (AH != NULL){
		if (deletedata == 1){
			/* Si deletedata=1, on libère aussi les données pointées par chaque case. */
			assert(AH->freeHeapData != NULL); 
			for (int i = 0; i < AH->N; i++){
				AH->freeHeapData(AH->A[i]); 
			}
		}
		/* Note : on ne free pas AH->A ici (car souvent A est géré ailleurs).
		 * Si tu veux libérer A aussi, il faut une fonction dédiée ou un flag supplémentaire. */
		free(AH); 
	}
}

void* ArrayHeapExtractMin(ArrayHeap* AH) {
	assert(AH); 
	/* Extraction sur tas vide -> NULL. */
	if (AH->N == 0){
		return NULL; 
	}
	else if (AH->N == 1){
		/* Cas simple : un seul élément, pas besoin de heapify. */
		AH->N--; 
		return AH->A[0]; 
	}
	else {
		/* On échange racine et dernier élément, on "supprime" le dernier,
		 * puis on rétablit la propriété de tas en descendant. */
		Switch(AH, 0, AH->N-1); 
		AH->N--; 
		updateArrayHeapDownwards(AH, 0); 
		/* On retourne l'élément extrait (qui se retrouve à l'ancienne dernière position). */
		return AH->A[AH->N]; 
	}
}

/**********************************************************************************
 * COMPLETE BINARY TREE HEAP
 **********************************************************************************/

/* Construit un tas basé sur un arbre binaire complet (CBTree) + comparateur preceed. */
CBTHeap* newCBTHeap(int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	assert(preceed);
	assert(viewHeapData);
	assert(freeHeapData);
	CBTHeap* newCBTHeap = malloc(sizeof(CBTHeap));
	assert(newCBTHeap);
	/* L'arbre complet stocke les données, et possède ses propres fonctions view/free. */
	newCBTHeap->T = newCBTree(viewHeapData, freeHeapData);
	newCBTHeap->preceed = preceed;
	newCBTHeap->viewHeapData = viewHeapData;
	newCBTHeap->freeHeapData = freeHeapData;
	return newCBTHeap;
}

/* Accesseur : renvoie le CBTree interne. */
CBTree* getCBTree(const CBTHeap* H) {
	return H->T;
}

/**
 * @brief Corrige la position du nœud à la position \p pos
 * de l'arbre raciné à \p node en le comparant avec son père
 * et en l'échangeant avec lui si nécessaire.
 * Le pointeur de fonction \p preceed est utilisé pour la comparaison.
 *
 *
 * Procédure récursive. En descendant, on cherche le premier nœud
 * à corriger qui se trouve dans la position \p pos (de la même façon
 * que dans insertAfterLastTNode). En remontant, on corrige en échangeant
 * avec le père, si besoin.
 *
 * @param[in] node
 * @param[in] pos
 * @param[in] preceed
 */
static void updateCBTHeapUpwards(TNode* node, int pos, int (*preceed)(const void*, const void*)) {
	/* pos==0 => racine, pas de père : rien à remonter. node==NULL => arbre vide. */
	if (pos != 0 && node != NULL) {
		//----------DESCENTE dédiée à la recherche du noeud à la position pos

		// On passe en base 1 pour manipuler plus facilement la structure de l'arbre en utilisant les nombres binaires
		int pos_B1 = pos + 1;

		// Recherche du bit de poids fort (Rq : La puissance de 2 de notre bit de poids fort indique dans quel niveau de l'arbre se trouve pos)
		int bitPoidsFort = 1;
		while(bitPoidsFort <= pos_B1) {
			bitPoidsFort = bitPoidsFort << 1;
		}
		bitPoidsFort = bitPoidsFort >> 1;

		/* On utilise le bit de poids fort pour récupérer le bit de direction (<=> 2nd bit de poids fort) afin de savoir si nous devons nous diriger vers
		le fils gauche ou le fils droit (Rappel : Tous les bits de pos_b1 à partir du bit de direction nous indiques le chemin jusqu'à pos) */
		int masqueRecupBitDirection = bitPoidsFort >> 1; // Nous obtenons alors un masque n'ayant qu'un seul bit à 1 et se trouvant au niveau du bit de direction de pos_B1

		// Cas de sécurité : si aucun bit de direction n’existe (racine atteinte ou position invalide),
		// il n’y a pas de descente possible dans l’arbre, on arrête la procédure.
		if (masqueRecupBitDirection == 0) return;

		// Variable permettant de savoir si nous devons nous diriger vers le fils droit ou le fils gauche
		int choisirFilsDroit = pos_B1 & masqueRecupBitDirection;
		/* choisirFilsDroit ne peut prendre que 2 valeurs : 0 ou masqueRecupBitDirection
		 * SI nous obtenons la valeur 0 ALORS nous devrons aller à gauche (puisque le bit de direction de pos_B1 == 0)
		 * SINON nous devrons aller à droite (puisque le bit de direction de pos_B1 == 1)*/

		// MAJ de notre nouvelle position dans le sous arbre
		// Récupération du chemin restant
		int CheminRestant = pos_B1 & (masqueRecupBitDirection - 1);
		/* La partie (masqueRecupBitDirection - 1) permet d'avoir un nouveau maque ne contenant que des 1 après le bit de direction,
		 * Ce masque temporaire permet de récupérer tous les bits de pos_B1 qui succèdent le bit de direction (<=> cheminRestant jusqu'à pos)
		 */

		// On détermine la nouvelle position dans le sous arbre en ajoutant le bit de direction qui représente la nouvelle racine ainsi que le niveau dans le sous arbre (ATTENTION Valeur dans la base 1)
		int nouvellePos_B1 = masqueRecupBitDirection + CheminRestant;
		int nouvellePos = nouvellePos_B1 - 1;

		//----APPEL RECURSIF + REMONTEE dédiée à l'échange (père, fils) dans l'hypothèse où la propriétée du tas n'est pas respectée
		if (choisirFilsDroit == 0) {
			/* Descente dans le sous-arbre gauche selon le chemin binaire calculé. */
			updateCBTHeapUpwards(node->left, nouvellePos, preceed);
			// REMONTEE
			/* En remontant, on compare le fils choisi au parent : si le fils a meilleure priorité,
			 * on échange uniquement les data (pas les pointeurs de nœuds). */
			if (node->left != NULL && node->data != NULL && node->left->data != NULL) {
				if (preceed(node->left->data, node->data) == 1) {
					void* tmpData = node->left->data;
					node->left->data = node->data;
					node->data = tmpData;
				}
			}
		}
		else {
			/* Descente dans le sous-arbre droit selon le chemin binaire calculé. */
			updateCBTHeapUpwards(node->right, nouvellePos, preceed);
			// REMONTEE
			if (node->right != NULL && node->data != NULL && node->right->data != NULL) {
				if (preceed(node->right->data, node->data) == 1) {
					void* tmpData = node->right->data;
					node->right->data = node->data;
					node->data = tmpData;
				}
			}
		}
	}
}

void CBTHeapInsert(CBTHeap *H, void* data) {
	assert(H);
	assert(data);
	assert(H->preceed);

	/* Insertion dans l'arbre complet à la prochaine position disponible (dernier niveau rempli à gauche). */
	CBTreeInsert(H->T, data);
	/* Puis correction vers le haut depuis la position du nouvel élément (numelm-1). */
	updateCBTHeapUpwards(H->T->root, H->T->numelm-1, H->preceed);
}

/**
 * @brief Corrige la position du nœud \p node en le comparant avec ses fils
 * et en l'échangeant avec le fils de la plus grande priorité si nécessaire.
 * Le pointeur de fonction \p preceed est utilisé pour la comparaison.
 *
 * Procédure récursive.
 *
 * NB: Le sous-arbre avec racine \p node ne peut pas être vide.
 * 
 * @param[in] node 
 * @param[in] preceed 
 */
static void updateCBTHeapDownwards(TNode* node, int (*preceed)(const void*, const void*)) {
	/* On ne fait quelque chose que si au moins un fils existe. */
	if (node->left != NULL || node->right != NULL) {
		/* On suppose d'abord que le meilleur fils est le fils gauche. */
		TNode* FilsAvecLaPlusGrandePriorite = node->left;


		if (FilsAvecLaPlusGrandePriorite == NULL) {
			/* Si pas de gauche, alors le droit est forcément le candidat. */
			FilsAvecLaPlusGrandePriorite = node->right;
		}
		else {
			/* Si les deux existent, on choisit celui qui "précède" l'autre selon preceed. */
			if (node->right != NULL && preceed(node->right->data, FilsAvecLaPlusGrandePriorite->data) == 1) {
				FilsAvecLaPlusGrandePriorite = node->right;
			}
		}


		/* Si le meilleur fils a meilleure priorité que le parent, on échange et on continue. */
		if (preceed(FilsAvecLaPlusGrandePriorite->data, node->data) == 1) {
			void* tmpData = FilsAvecLaPlusGrandePriorite->data;
			FilsAvecLaPlusGrandePriorite->data = node->data;
			node->data = tmpData;
			updateCBTHeapDownwards(FilsAvecLaPlusGrandePriorite, preceed);
		}
	}
}

void * CBTHeapExtractMin(CBTHeap *H) {
	assert(H);
	assert(H->T);
	assert(H->preceed);

	/* Extraction sur tas vide. */
	if (H->T->numelm == 0) {
		return NULL;
	}
	else if (H->T->numelm == 1) {
		/* Un seul élément : remove renvoie directement la data. */
		return CBTreeRemove(H->T);
	}
	else {
		// LastNodeData stock la data du dernier élément du tas qui a été supprimé
		/* On supprime le dernier nœud (le plus à droite au dernier niveau) :
		 * CBTreeRemove renvoie sa data. */
		void* LastNodeData = CBTreeRemove(H->T);
		// Echange entre la data de la racine de l'arbre (l'élément avec la plus grande priorité) et LastNodeData
		/* On met la data du dernier nœud à la racine (swap data),
		 * et on garde l'ancienne racine dans LastNodeData pour la retourner. */
		void* tmpData = LastNodeData;
		LastNodeData = H->T->root->data;
		H->T->root->data = tmpData;
		// Correction vers le bas
		updateCBTHeapDownwards(H->T->root, H->preceed);
		// On retourne la valeur qui avait la plus grande priorité dans notre tas
		return LastNodeData;
	}
}

void viewCBTHeap(const CBTHeap * H) {
	//TODO
	/* Idée possible : afficher l'arbre complet sous forme niveau par niveau,
	 * ou réutiliser une fonction viewCBTree si elle existe dans tree.c. */
}

void freeCBTHeap(CBTHeap* H, int deletenode) {
	/* deletenode joue le même rôle que dans freeCBTree :
	 * 1 -> libère aussi les data via freeData ; 0 -> ne libère que les nœuds. */
	if (H != NULL) {
		if (H->T != NULL) {
			/* * Libération de l'arbre :
			 * Si deletenode = 1, les données sont supprimées via H->T->freeData.
			 * Si deletenode = 0, seules les structures de l'arbre sont supprimées.
			 */
			freeCBTree(H->T, deletenode);
		}

		// Enfin, on libère la structure CBTHeap elle-même
		free(H);
	}
}
