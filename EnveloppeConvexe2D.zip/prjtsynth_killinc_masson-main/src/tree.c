#include <stdio.h>
#include <stdlib.h>

#include "../include/tree.h"

/********************************************************************
 * TNode
 ********************************************************************/

/* ========================= AJOUT =========================
 * Partie TNode :
 * Un TNode représente un nœud d’arbre binaire, contenant :
 *  - data : pointeur générique vers une donnée
 *  - left/right : pointeurs vers les fils gauche/droit
 * ========================================================= */

TNode * newTNode(void* data) {
	TNode *res = malloc(sizeof(TNode));
	/* AJOUT : ici on suppose malloc réussi (pas de assert). */
	res->data = data;
	res->left = NULL;
	res->right = NULL;
	return res;
}

/* AJOUT : accesseur simple (ne copie pas la donnée, renvoie juste le pointeur). */
void* getTNodeData(const TNode* node) {
	return node->data;
}

/* AJOUT : renvoie le fils gauche (peut être NULL si absent). */
TNode* Left(const TNode* node) {
	return node->left;
}

/* AJOUT : renvoie le fils droit (peut être NULL si absent). */
TNode* Right(const TNode* node) {
	return node->right;
}

/* AJOUT : remplace le pointeur data (ne libère pas l’ancienne donnée). */
void setTNodeData(TNode* node, void* newData) {
	node -> data = newData;
}

/* AJOUT : relie node à un nouveau fils gauche (peut être NULL). */
void setLeft(TNode* node, TNode* newLeft) {
	node -> left = newLeft;
}

/* AJOUT : relie node à un nouveau fils droit (peut être NULL). */
void setRight(TNode* node, TNode* newRight) {
	node -> right = newRight;
}

/********************************************************************
 * Complete Binary Tree
 ********************************************************************/

/* ========================= AJOUT =========================
 * Partie CBTree (Complete Binary Tree) :
 * - Arbre binaire "complet" : tous les niveaux sont remplis de gauche à droite
 * - numelm : nombre total de nœuds
 * - root : racine
 * - viewData/freeData : callbacks pour afficher/libérer les data
 * ========================================================= */

CBTree * newCBTree(void (*viewData)(const void*), void (*freeData)(void*)) {
	CBTree *res = malloc(sizeof(CBTree));
	/* AJOUT : arbre initialement vide */
	res -> root = NULL;
	res -> numelm = 0;
	res -> viewData = viewData;
	res -> freeData = freeData;
	return res;
}

/* AJOUT : T==NULL est considéré comme "vide" pour éviter des segfaults. */
int treeIsEmpty(CBTree* T) {
	return (T == NULL || T->numelm == 0);
}

/* AJOUT : renvoie simplement numelm (suppose T non NULL). */
int getCBTreeSize(const CBTree* T) {
	return T->numelm;
}

/* AJOUT : accesseur racine (peut être NULL si arbre vide). */
TNode* Root(const CBTree* T) {
	return T->root;
}

/* AJOUT : utilitaire de maintenance du compteur (structure inchangée). */
void increaseCBTreeSize(CBTree* T) {
	T -> numelm++;
}

/* AJOUT : utilitaire de maintenance du compteur (structure inchangée). */
void decreaseCBTreeSize(CBTree* T) {
	T -> numelm--;
}

/* AJOUT : remet uniquement numelm à 0  (ne libère rien, ne change pas root). */
void resetCBTreeSize(CBTree* T) {
	T -> numelm = 0;
}

/* AJOUT : change la racine (ne libère rien). */
void setRoot(CBTree* T, TNode* newRoot) {
	T -> root = newRoot;
}

/**
 * @brief Libère récursivement le sous-arbre raciné au nœud \p node.
 * Dans le cas où le pointeur de fonction \p freeData n'est pas NULL,
 * la mémoire de la donnée du nœud actuel est aussi libérée.
 * NB : procédure récursive.
 *
 * @param[in] node
 * @param[in] freeData
 *
 * AJOUT : parcours postfixé (gauche → droite → nœud),
 * ce qui garantit qu’on libère les enfants avant le parent.
 */
static void freeTNode(TNode* node, void (*freeData)(void*)) {

	if (node == NULL)
		return;

	freeTNode(node -> left, freeData);
	freeTNode(node -> right, freeData);

	if (freeData != NULL && node -> data != NULL)
		freeData(node -> data);

	free(node);
}

/**
 * NB : Utilisez la procédure récursive freeTNode.
 * Vous devez initialiser le paramètre freeData
 * par rapport à la valeur de deleteData.
 *
 * AJOUT : deleteData = 1 ⇒ libère aussi les data via T->freeData
 *        deleteData = 0 ⇒ libère uniquement les nœuds
 */
void freeCBTree(CBTree * T, int deleteData) {
	if (T == NULL) return;
	void (*freeData)(void*) = NULL;

	if (deleteData == 1)
		freeData = T->freeData;

	freeTNode(T->root, freeData);

	free(T);


}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours préfixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 *
 * @param[in] node
 * @param[in] viewData
 *
 * AJOUT : préfixé = nœud → gauche → droite
 */
static void preorder(TNode *node, void (*viewData)(const void*)) {
	if (node == NULL)
		return;
	viewData(node->data);
	preorder(node->left, viewData);
	preorder(node->right, viewData);
}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours infixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 *
 * @param[in] node
 * @param[in] viewData
 *
 * AJOUT : infixé = gauche → nœud → droite
 */
static void inorder(TNode *node, void (*viewData)(const void*)) {
	if (node == NULL)
		return;
	inorder(node->left, viewData);
	viewData(node->data);
	inorder(node->right, viewData);
}

/**
 * @brief Affiche les éléments de l'arbre raciné au nœud \p node
 * en réalisant un parcours postfixé.
 * Les données de chaque nœud sont afficher en utilisant le
 * pointer de fonction \p viewData.
 *
 * @param[in] node
 * @param[in] viewData
 *
 * AJOUT : postfixé = gauche → droite → nœud
 */
static void postorder(TNode *node, void (*viewData)(const void*)) {
	if (node == NULL)
		return;
	postorder(node->left, viewData);
	postorder(node->right, viewData);
	viewData(node->data);
}

/**
 * NB : Utilisez les procédures récursives preorder, inorder et postorder.
 * Rappel : order = 0 (preorder), 1 (postorder), 2 (inorder)
 *
 * AJOUT : order invalide ⇒ message d’erreur, pas d’affichage.
 */
void viewCBTree(const CBTree* T, int order) {
	if (order == 0)
		preorder(T->root, T->viewData);
	else if (order == 2)
		inorder(T->root, T->viewData);
	else if (order == 1)
		postorder(T->root, T->viewData);
	else
		printf("Erreur : order doit être égal à 0, 1 ou 2\n");
}

/**
 * @brief Insère récursivement un nouveau nœud de donnée \p data
 * dans l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) où le nouveau nœud
 * va être insérer est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 *
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 *
 * @param[in] node La racine de l'arbre actuel.
 * @param[in] position La position du nouveau élément
 * 						par rapport à la racine \p node.
 * @param[in] data La donnée à insérer.
 * @return TNode* Le nœud \p node mis à jour.
 *
 * AJOUT : idée générale :
 * - position correspond à l’index en représentation tableau (heap-like)
 * - on utilise la décomposition binaire (via puissances de 2) pour retrouver
 *   le chemin gauche/droite jusqu’au parent cible.
 */

static TNode* insertAfterLastTNode(TNode* node, int position, void* data) {
	//Des commentaires plus détaillés sur la méthode mathématique sont présents dans removeLastTNode (en dessous)

	if (position == 0)
		return newTNode(data);

	// Sécurité : Si position != 0 mais que node est NULL, c'est un problème d'arbre corrompu
	if (node == NULL)
		return NULL;

	//Cas de base (inchangés)
	if (position == 1) {
		node->left = newTNode(data);
		return node;
	}
	if (position == 2) {
		node->right = newTNode(data);
		return node;
	}

	// On passe en Base 1 (plus simple pour les divisions)
	int n = position + 1;

	// Trouver la plus grande puissance de 2 (P) contenue dans n
	// Ex: si n=9, P sera 8. Si n=5, P sera 4.
	int p = 1;
	while (p <= n) {
		p = p * 2;
	}
	p = p / 2;

	// Trouver la direction
	// On regarde le "demi-bloc" suivant (P divisé par 2)
	int half_p = p / 2;

	// Si la division donne 2 -> C'est GAUCHE
	// Si la division donne 3 -> C'est DROITE
	// (Mathématiquement : 2 veut dire "première moitié", 3 veut dire "seconde moitié")
	int direction = n / half_p;

	// 5. Calcul de la nouvelle position
	// On garde le reste de la division (la "queue" du chiffre)
	int reste = n % half_p;

	// On recolle le "1" devant le reste
	int new_n = half_p + reste;

	// On repasse en Base 0 pour l'appel suivant
	int new_position = new_n - 1;

	/* AJOUT : ici, direction permet de décider dans quel sous-arbre
	 * se situe la position cible. On descend récursivement jusqu’aux cas de base. */
	if (direction == 2) {
		node->left = insertAfterLastTNode(node->left, new_position, data);
	} else {
		node->right = insertAfterLastTNode(node->right, new_position, data);
	}
	return node;

}

/**
 * NB : Utilisez la procédure récursive insertAfterLastTNode
 * afin de lancer l'insertion.
 *
 * AJOUT : on insère à la position numelm (prochaine case libre en parcours niveau).
 */
void CBTreeInsert(CBTree* T, void* data) {
	T->root = insertAfterLastTNode(T->root, T->numelm, data);
	increaseCBTreeSize(T);
}

/**
 * @brief Supprime récursivement le dernier nœud
 * de l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) du nœud à supprimer
 * est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 * La mémoire du dernier nœud est libérée mais pas la mémoire de sa donnée.
 *
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 *
 * @param[in] node La racine de l'arbre actuel.
 * @param[in] position La position de l'élément à supprimer
 *                         par rapport à la racine \p node.
 * @param[out] data La donnée du nœud supprimé (sortie).
 * @return TNode* Le nœud \p node mis à jour.
 *
 * AJOUT : cette fonction fait l’inverse de l’insertion :
 * - elle retrouve le dernier nœud (position numelm-1)
 * - elle libère le nœud, et remonte en mettant à jour les pointeurs.
 */
static TNode* removeLastTNode(TNode* node, int position, void** data) {

	//Sécurité avant de regarder la position, car cette fois ci on veut supprimer et non créer
	if (node == NULL) {
		printf ("Problème avec la fonction removeLastTNode \n");
		return NULL;
	}

	// Arbre vide : on retourne rien
	if (position == 0) {
		if (data != NULL)
			*data = node->data;
		free(node);
		return NULL;
	}

	// 1 est à gauche, donc on va à gauche
	if (position == 1) {
		if (data != NULL)
			*data = node -> left -> data;
		free(node -> left);
		setLeft (node, NULL);
		return node;
	}
	// 2 est à droite donc on va à droite
	if (position == 2) {
		if (data != NULL)
			*data = node -> right -> data;
		free(node -> right);
		setRight (node, NULL);
		return node;
	}

	/* Pour avoir une égalité entre le niveau de l'arbre et le nombre de bits en binaire
	*		Exemple:
	*
	*          1
	*       /     \
	*     10      11
	*     / \     / \
	*   100 101  110 111
	*   / \
	* 1000 ...
	*
	*	Ceci permet d'utiliser la propriété mathématique qui suit, car chaque puissance de 2 représente
	*	un niveau
	*/

	int n = position + 1;

	// Trouver la plus grande puissance de 2 (p) <= à n
	// Ex: si n=9, p=8. Si n=5, p=4. n=20, p=16 etc...
	int p = 1;
	while (p <= n) {
		p = p * 2;
	}
	p = p / 2;

	// Ici, le but est de trouver la direction
	// On regarde le deuxième bit de poids fort, pour ça on a besoin de half_p
	int half_p = p / 2;

	// Si position=8, n=9 (1001), p=8, half_p=4 (100), si on fait la division entière de n par half_p,
	// on remarque qu'on a 2 si le deuxième bit est 0, et 3 si ce bit est à 1, on peut se déplacer
	int direction = n / half_p;

	// Calcul de la nouvelle position
	// On garde le reste de la division (la "queue" du chiffre), ce qu'il y a après le deuxième bit
	int reste = n % half_p;

	// On recolle le "1" du bit de poids fort (half_p) devant le reste (les autres bits)
	int new_n = half_p + reste;

	// On a initialement ajouté 1 à n, donc maintenant on lui enlève 1 pour ne pas fausser les
	// calculs dans l'appel récursif.
	int new_position = new_n - 1;

	// Appel récursif
	if (direction == 2) {
		// GAUCHE
		node->left = removeLastTNode(node->left, new_position, data);
	}
	else {
		// DROITE
		node->right = removeLastTNode(node->right, new_position, data);
	}

	return node;
}

/**
 * NB : Utilisez la procédure récursive removeLastTNode
 * afin de lancer la suppression.
 *
 * AJOUT : on supprime l’élément numelm-1 (dernier élément du parcours niveau).
 */
void* CBTreeRemove(CBTree* T) {

	// Sécurité : Si l'arbre est vide, on renvoie NULL
	if (T == NULL || T->numelm == 0) {
		return NULL;
	}

	void* res = NULL;

	T->root = removeLastTNode(T->root, T->numelm-1, &res);

	decreaseCBTreeSize(T);

	return res;
}

/**
 * @brief Restitue récursivement le dernier nœud
 * de l'arbre raciné au nœud \p node.
 * La position (par rapport à la racine \p node) de ce dernier nœud
 * est indiquée par le paramètre \p position
 * (voir la figure ci-dessous pour la définition de la position).
 *
 *          0
 *       /     \
 *      1       2
 *     / \     / \
 *    3   4   5   6
 *   / \
 *  7  ...
 *
 * @param node La racine de l'arbre actuel.
 * @param position La position du dernier nœud par rapport à la racine \p node.
 * @return TNode* Le dernier nœud de l'arbre.
 *
 * AJOUT : même logique de navigation que removeLastTNode, mais ici
 * on ne supprime pas : on retourne juste l’adresse du nœud trouvé.
 */
static TNode* getLastTNode(TNode* node, int position) {

	//Sécurité avant de regarder la position, même logique qu'avec supprimer
	if (node == NULL) {
		printf ("Problème avec la fonction getLastTNode \n");
		return NULL;
	}

	if (position == 0)
		return node;

	// Cas de base
	if (position == 1) {
		return node->left;
	}
	if (position == 2) {
		return node->right;
	}

	// On passe en Base 1
	int n = position + 1;

	// Trouver la plus grande puissance de 2 (p) contenue dans n
	// Exemple : si n=9, p sera 8. Si n=5, p sera 4.
	int p = 1;
	while (p <= n) {
		p = p * 2;
	}
	p = p / 2;

	// Trouver la direction
	// On regarde le "demi-bloc" suivant (P divisé par 2)
	int half_p = p / 2;

	// Si la division donne 2 -> C'est GAUCHE
	// Si la division donne 3 -> C'est DROITE
	// (Mathématiquement : 2 veut dire "première moitié", 3 veut dire "seconde moitié")
	int direction = n / half_p;

	// Calcul de la nouvelle position
	// On garde le reste de la division (la "queue" du chiffre)
	int reste = n % half_p;

	// On recolle le "1" (half_p) devant le reste
	int new_n = half_p + reste;

	// On repasse en Base 0 pour l'appel suivant
	int new_position = new_n - 1;

	// Appel récursif
	if (direction == 2) {
		// GAUCHE
		return getLastTNode(node->left, new_position);
	}
	else {
		// DROITE
		return getLastTNode(node->right, new_position);
	}
}

/**
 * NB : Utilisez la procédure récursive getLastTNode
 * afin de lancer la recherche.
 *
 * AJOUT : renvoie le dernier nœud (position numelm-1) si l’arbre n’est pas vide.
 */
TNode* CBTreeGetLast(CBTree* T) {
	//Sécurité
	if (treeIsEmpty(T))
		return NULL;

	return getLastTNode(T->root, T->numelm-1);
}


/* AJOUT : échange uniquement les pointeurs data, pas les nœuds eux-mêmes. */
void CBTreeSwapData(TNode* node1, TNode* node2) {
	if (node1 == NULL || node2 == NULL) return;

	void *tmp = node1->data;
	node1->data = node2->data;
	node2->data = tmp;
}
