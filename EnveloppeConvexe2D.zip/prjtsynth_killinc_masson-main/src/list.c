#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "../Include/util.h"
#include "../Include/list.h"

/********************************************************************
 * LNode
 ********************************************************************/

/* Crée un nouveau nœud de liste doublement chaînée.
 * - data : pointeur générique vers la donnée stockée
 * - succ/pred initialisés à NULL (nœud isolé) */
LNode * newLNode(void* data) {
	LNode * newNode = (LNode*)malloc(sizeof(LNode));
	assert(newNode);                      

	newNode->data = data; 
	newNode->succ = NULL; 
	newNode->pred = NULL; 
	return newNode; 
}

/* Accesseur : renvoie la donnée contenue dans le nœud. */
void* getLNodeData(const LNode* node) {
	assert(node);                         
	return node->data; 
}

/* Accesseur : renvoie le successeur (nœud suivant) */
LNode* Successor(const LNode* node) {
	assert(node);                         
	return node->succ; 
}

/* Accesseur : renvoie le prédécesseur (nœud précédent) */
LNode* Predecessor(const LNode* node) {
	assert(node);                         
	return node->pred; 
}

/* Modifie la donnée stockée dans le nœud. */
void setLNodeData(LNode* node, void* newData) {
	assert(node);                         
	node->data = newData; 
}

/* Modifie le pointeur vers le successeur. */
void setSuccessor(LNode* node, LNode* newSucc) {
	assert(node);                         
	node->succ = newSucc; 
}

/* Modifie le pointeur vers le prédécesseur. */
void setPredecessor(LNode* node, LNode* newPred) {
	assert(node);                         
	node->pred = newPred; 
}

/********************************************************************
 * List
 ********************************************************************/

/* Crée une nouvelle liste doublement chaînée vide.
 * viewData : fonction d'affichage d'un élément (void*)
 * freeData : fonction de libération d'un élément (void*) */
List * newList(void (*viewData)(const void*), void (*freeData)(void*)) {
	assert(viewData);                     
	assert(freeData);                     

	List * newListe = (List*)malloc(sizeof(List));
	assert(newListe);                     

	/* Liste vide : head/tail = NULL, taille = 0 */
	newListe->head = NULL; 
	newListe->tail = NULL; 
	newListe->numelm = 0; 

	/* Pointeurs de fonctions stockés pour view/free */
	newListe->freeData = freeData; 
	newListe->viewData = viewData; 

	return newListe; 
}

/* Renvoie 1 si la liste est vide, 0 sinon. */
int listIsEmpty(List* L) {
	assert(L);                            
	return (L->numelm == 0); 
}

/* Renvoie le nombre d'éléments de la liste. */
int getListSize(const List* L) {
	assert(L);                            
	return L->numelm; 
}

/* Accesseur tête (premier nœud). */
LNode* Head(const List* L) {
	assert(L);                            
	return L->head; 
}

/* Accesseur queue (dernier nœud). */
LNode* Tail(const List* L) {
	assert(L);                            
	return L->tail;
}

/* Incrémente le compteur d'éléments. */
void increaseListSize(List* L) {
	assert(L);                           
	++L->numelm; 
}

/* Décrémente le compteur d'éléments. */
void decreaseListSize(List* L) {
	assert(L);                           
	--L->numelm; 
}

/* Affecte une nouvelle taille (à utiliser avec prudence). */
void setListSize(List* L, int newSize) {
	assert(L);                            
	assert(newSize >= 0);                 
	L->numelm = newSize; 
}

/* Remet la taille à 0 (ne libère PAS les nœuds).
 * À utiliser uniquement si la structure est gérée ailleurs. */
void resetListSize(List* L) {
	assert(L);                            
	L->numelm = 0; 
}

/* Modifie la tête. */
void setHead(List* L, LNode* newHead) {
	assert(L);                            
	L->head = newHead; 
}

/* Modifie la queue. */
void setTail(List* L, LNode* newTail) {
	assert(L);                            
	L->tail = newTail; 
}

/* Libère la liste.
 * deleteData :
 *  - 1 => libère aussi les data via freeData
 *  - 0 => libère uniquement les nœuds */
void freeList(List * L, int deleteData) {
	assert(deleteData == 0 || deleteData == 1);   
	if (!L) return;

	if (deleteData == 1) {
		assert(L->freeData);              
	}

	LNode* curr = L->head;
	while (curr != NULL) {
		LNode* next = curr->succ;

		if (deleteData == 1) {
			L->freeData(curr->data);
		}

		free(curr);
		curr = next;
	}

	free(L);
}

/* Affiche tous les éléments dans l'ordre de la liste (head -> tail). */
void viewList(const List * L) {
	assert(L);                            
	assert(L->viewData);                  

	for (LNode* tmpNode = L->head; tmpNode; tmpNode = tmpNode->succ){
		L->viewData(tmpNode->data); 
	}
}

/* Insère un élément en tête de liste. */
void listInsertFirst(List * L, void * data) {
	assert(L);                            

	LNode * newHeadNode = newLNode(data);
	
	if (L->head == NULL){
		L->head = newHeadNode; 
		L->tail = newHeadNode; 
	}
	else {
		newHeadNode->succ = L->head; 
		L->head->pred = newHeadNode; 
		L->head = newHeadNode; 
	}

	increaseListSize(L); 
}

/* Insère un élément en fin de liste. */
void listInsertLast(List * L, void * data) {
	assert(L);                            

	LNode * newTailNode = newLNode(data);
	
	if (L->head == NULL){
		L->head = newTailNode; 
		L->tail = newTailNode; 
	}
	else {
		L->tail->succ = newTailNode; 
		newTailNode->pred = L->tail; 
		L->tail = newTailNode; 
	}

	increaseListSize(L); 
}

/* Insère un nouvel élément juste après le nœud ptrelm. */
void listInsertAfter(List * L, void * data, LNode * ptrelm) {
	assert(L);                            
	assert(ptrelm);                       

	LNode * newNodeToInsert = newLNode(data);

	newNodeToInsert->pred = ptrelm; 
	newNodeToInsert->succ = ptrelm->succ; 
	ptrelm->succ = newNodeToInsert; 

	if (newNodeToInsert->succ == NULL){
		L->tail = newNodeToInsert; 
	}
	else {
		newNodeToInsert->succ->pred = newNodeToInsert; 
	}

	increaseListSize(L); 
}

/* Retire le premier élément et renvoie sa data (sans la free). */
void* listRemoveFirst(List * L) {
	assert(L);                           

	if (L->numelm <= 0){
		return NULL; 
	}

	assert(L->head);                      
	LNode * tmpNode = L->head; 
	void * tmpData = tmpNode->data; 

	if (L->numelm > 1){
		assert(L->head->succ);             
		L->head->succ->pred = NULL; 
		L->head = L->head->succ; 
	}
	else {
		L->head = NULL; 
		L->tail = NULL; 
	}

	decreaseListSize(L); 
	free(tmpNode); 
	return tmpData; 
}

/* Retire le dernier élément et renvoie sa data (sans la free). */
void* listRemoveLast(List * L) {
	assert(L);                           

	if (L->numelm <= 0){
		return NULL; 
	}

	assert(L->tail);                     

	LNode * tmpNode = L->tail; 
	void* tmpData = tmpNode->data; 

	if (L->numelm > 1){
		assert(L->tail->pred);             
		L->tail->pred->succ = NULL; 
		L->tail = L->tail->pred; 
	}
	else {
		L->head = NULL; 
		L->tail = NULL; 
	}

	decreaseListSize(L); 
	free(tmpNode); 
	return tmpData; 
}

/* Retire un nœud arbitraire et renvoie sa data (sans la free). */
void* listRemoveNode(List * L, LNode * node) {
	assert(L);                            
	assert(node);                         

	if (L->head == node){
		return listRemoveFirst(L); 
	}
	else if (L->tail == node){
		return listRemoveLast(L); 
	}
	else {
		assert(node->pred);                
		assert(node->succ);                

		void* tmpData = node->data; 

		node->pred->succ = node->succ; 
		node->succ->pred = node->pred; 

		free(node); 
		decreaseListSize(L); 
		return tmpData; 
	}
}

/* Concatène L2 à la fin de L1 (en O(1)). */
List* listConcatenate(List* L1, List* L2) {
	assert(L1);                          
	assert(L2);                           

	assert(L1->viewData == L2->viewData); 
	assert(L1->freeData == L2->freeData); 

	if (L1->numelm == 0){
		free(L1); 
		return L2; 
	}

	if (L2->numelm == 0){
		free(L2); 
		return L1; 
	}

	assert(L1->tail);                     
	assert(L2->head);                     

	L1->tail->succ = L2->head; 
	L2->head->pred = L1->tail; 
	L1->tail = L2->tail; 

	setListSize(L1, L1->numelm + L2->numelm); 

	free(L2); 
	return L1; 
}
