#include "../include/heap.h"
#include "../include/sort.h"

#include <assert.h>

/********************************************************************
 * Heap Sort avec tas tableau (ArrayHeap)
 ********************************************************************/

/*
 * Trie le tableau A de taille N en utilisant un tas binaire implémenté
 * sous forme de tableau (ArrayHeap).
 *
 * Principe :
 *  1) Construire un tas à partir du tableau A
 *  2) Extraire successivement l'élément de plus haute priorité
 *  3) Reconstruire le tableau trié
 *
 * Le tri n'est effectué que si N > 1 (cas triviaux ignorés).
 */
void ArrayHeapSort(void** A, int N,
                   int (*preceed)(const void*, const void*),
                   void (*viewHeapData)(const void*),
                   void (*freeHeapData)(void*)) {
	assert(A);

	/* Gestion des cas particuliers :
	 * - N = 0 ou N = 1 : le tableau est déjà trié */
	if (N > 1) {

		/* Construction du tas tableau à partir de A */
		ArrayHeap* ArrayHeapToSort =
			ArrayToArrayHeap(A, N, preceed, viewHeapData, freeHeapData);

		/* Extraction successive du minimum :
		 * les éléments sont replacés dans A en partant de la fin */
		for (int i = 0; i < N; i++) {
			A[(N-1)-i] = ArrayHeapExtractMin(ArrayHeapToSort);
		}

		/* Libération de la structure du tas (sans libérer les données) */
		freeArrayHeap(ArrayHeapToSort, 0);

		/* Inversion du tableau :
		 * l'extraction produit un tableau trié dans l'ordre inverse */
		for (int i = 0; i < N/2; i++) {
			void* tmp = A[(N-1)-i];
			A[(N-1)-i] = A[i];
			A[i] = tmp;
		}
	}
}


/********************************************************************
 * Heap Sort avec tas basé sur arbre binaire complet (CBTHeap)
 ********************************************************************/

/*
 * Trie le tableau A de taille N en utilisant un tas implémenté
 * avec un arbre binaire complet.
 *
 * Principe :
 *  1) Insérer tous les éléments du tableau dans le tas
 *  2) Extraire successivement l'élément de plus haute priorité
 *  3) Remplacer les éléments du tableau dans l'ordre d'extraction
 */
void CBTHeapSort(void** A, int N,
					int (*preceed)(const void*, const void*),
					void (*viewHeapData)(const void*),
					void (*freeHeapData)(void*)) {
	assert(A);

	/* Cas triviaux : aucun tri nécessaire */
	if (N > 1) {

		/* Création d'un tas basé sur un arbre binaire complet */
		CBTHeap* HeapToSort = newCBTHeap(preceed, viewHeapData, freeHeapData);

		/* Insertion de tous les éléments du tableau dans le tas */
		for (int i = 0; i < N; i++) {
			CBTHeapInsert(HeapToSort, A[i]);
		}

		/* Extraction successive des éléments triés */
		for (int j = 0; j < N; j++) {
			A[j] = CBTHeapExtractMin(HeapToSort);
		}

		/* Libération du tas (sans libérer les données) */
		freeCBTHeap(HeapToSort, 0);
	}
}


/********************************************************************
 * Tri par sélection (Selection Sort)
 ********************************************************************/

/*
 * Trie le tableau A de taille N par l'algorithme du tri par sélection.
 *
 * Principe :
 *  - À chaque itération i, on cherche l'élément de plus haute priorité
 *    dans la partie non triée du tableau
 *  - On échange cet élément avec celui en position i
 *
 * Complexité :
 *  - Temps : O(N²)
 *  - Espace : O(1) (tri en place)
 */
void SelectionSort(void** A, int N, int (*preceed)(const void*, const void*)) {
	assert(A);
	assert(preceed);

	/* Si N <= 1, la boucle ne s'exécute pas :
	 * le tableau est déjà considéré comme trié */
	for (int i = 0; i < N-1; i++) {

		/* Indice de l'élément de plus haute priorité trouvé */
		int iMin = i;

		/* Recherche du minimum (selon preceed) dans la partie non triée */
		for (int j = i+1; j < N; j++) {
			if (preceed(A[j], A[iMin]) == 1) {
				iMin = j;
			}
		}

		/* Échange uniquement si un nouvel élément a été trouvé */
		if (iMin != i) {
			void* tmp = A[i];
			A[i] = A[iMin];
			A[iMin] = tmp;
		}
	}
}
