#include <stdio.h>
#include <stdlib.h>

#include "util.h"
#include "list.h"
#include "tree.h"
#include "heap.h"
#include "sort.h"
#include "geometry.h"
#include "algo.h"

void showHelp() {
	ShowMessage("make run in=infilename out=outfilename algo=algotihm [sort=sort]\n", 0);
	ShowMessage("algorithm:", 0);
	ShowMessage("\t1 - slow convex hull", 0);
	ShowMessage("\t2 - convex hull", 0);
	ShowMessage("\t3 - rapid convex hull\n", 0);
	ShowMessage("sort (only for algorithm=2):", 0);
	ShowMessage("\t1 - heap sort (using trees)", 0);
	ShowMessage("\t2 - heap sort (using arrays)", 0);
	ShowMessage("\t3 - selection sort", 0);
	ShowMessage("", 1);
}

int main(int argc, char *argv[]) {
	if (argc < 4)
		showHelp();

	char* infilename = argv[1];
	char* outfilename = argv[2];
	int algo = atoi(argv[3]);
	switch (algo) {
		case 1:
			SlowConvexHull(infilename, outfilename);
			break;
		case 2:
			if (argc != 5) {
				showHelp();
			}
			int sort = atoi(argv[4]);
			if (sort != 1 && sort != 2 && sort != 3) {
				ShowMessage("Wrong choice of sorting method.\n", 0);
				showHelp();
			}
			ConvexHull(infilename, outfilename, sort);
			break;
		case 3:
			RapidConvexHull(infilename, outfilename);
			break;
		default:
			ShowMessage("Wrong choice of algorithm.\n", 0);
			showHelp();
	}

	return EXIT_SUCCESS;
}