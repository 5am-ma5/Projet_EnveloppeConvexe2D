#include <stdio.h>
#include <stdlib.h>

#include "../include/geometry.h"

#include <assert.h>

/* =========================
 *  Structure Point
 * ========================= */

/* Alloue et initialise un point (x, y).
 * On utilise assert pour vérifier que malloc a bien réussi. */
Point* newPoint(long long int x, long long int y) {
    Point* p = malloc(sizeof(Point));
    assert(p);
    p->x = x;
    p->y = y;
    return p;
}

/* Accesseur : renvoie l'abscisse X du point P. */
long long int X(const Point* P) {
    assert(P);
    return P->x;
}

/* Accesseur : renvoie l'ordonnée Y du point P. */
long long int Y(const Point* P) {
    assert(P);
    return P->y;
}

/* Affiche un point sous la forme "(x, y)". */
void viewPoint(const void* P) {
    assert(P);
    const Point* p = (Point*)P;     // conversion void* -> Point*
    printf("(%lld, %lld)", X(p), Y(p));
}

/* Libère la mémoire associée à un point (si non NULL). */
void freePoint(void* P) {
    if (P) free(P);
}


/* =========================
 *  Orientation / position relative
 * ========================= */

/* Fonction privée (static) : calcule le déterminant (produit vectoriel 2D)
 * associé à la droite orientée origin -> destination et au point P.
 *
 * D = (XB - XA)*(YP - YA) - (YB - YA)*(XP - XA)
 *
 * - Si D > 0 : P est à gauche de la droite orientée
 * - Si D < 0 : P est à droite
 * - Si D = 0 : les points sont colinéaires
 *
 * static => visible uniquement dans geometry.c (pas accessible depuis ailleurs). */
static long long int DroiteOrientee(const Point* origin, const Point* destination, const Point* P) {
    assert(origin);
    assert(destination);
    assert(P);
    return (X(destination) - X(origin)) * (Y(P) - Y(origin))
         - (Y(destination) - Y(origin)) * (X(P) - X(origin));
}

/* Renvoie 1 si P est strictement à droite de la droite orientée origin->destination, sinon 0. */
int onRight(const Point* origin, const Point* destination, const Point* P) {
    long long int res = DroiteOrientee(origin, destination, P);
    return res < 0;
}

/* Renvoie 1 si P est strictement à gauche de la droite orientée origin->destination, sinon 0. */
int onLeft(const Point* origin, const Point* destination, const Point* P) {
    long long int res = DroiteOrientee(origin, destination, P);
    return res > 0;
}

/* Renvoie 1 si origin, destination et P sont colinéaires, sinon 0. */
int collinear(const Point* origin, const Point* destination, const Point* P) {
    long long int res = DroiteOrientee(origin, destination, P);
    return res == 0;
}


/* =========================
 *  Inclusion dans un segment
 * ========================= */

/* Renvoie 1 si P appartient au segment [origin, destination], sinon 0.
 *
 * Méthode :
 * 1) Vérifier la colinéarité (sinon impossible d'être dans le segment)
 * 2) Calculer le rectangle englobant formé par origin et destination
 * 3) Vérifier que P est dans ce rectangle (donc entre les bornes) */
int isIncluded(const Point* origin, const Point* destination, const Point* P) {
    assert(origin && destination && P);

    /* 1. Les trois points doivent être colinéaires */
    if (DroiteOrientee(origin, destination, P) != 0)
        return 0;

    /* 2. Calcul des bornes (xmin/xmax, ymin/ymax) */
    long long xmin, xmax, ymin, ymax;

    if (X(origin) < X(destination)) {
        xmin = X(origin);
        xmax = X(destination);
    } else {
        xmin = X(destination);
        xmax = X(origin);
    }

    if (Y(origin) < Y(destination)) {
        ymin = Y(origin);
        ymax = Y(destination);
    } else {
        ymin = Y(destination);
        ymax = Y(origin);
    }

    /* 3. Vérifier que P est dans le rectangle englobant,
     * ce qui garantit qu'il est bien "entre" origin et destination. */
    return (X(P) >= xmin && X(P) <= xmax &&
            Y(P) >= ymin && Y(P) <= ymax);
}


/* =========================
 *  Structure DEdge (arête orientée)
 * ========================= */

/* Alloue et initialise une arête orientée (origin -> destination). */
DEdge* newDEdge(Point* origin, Point* destination) {
    assert(origin);
    assert(destination);

    DEdge* res = malloc(sizeof(DEdge));
    assert(res);

    res->origin = origin;
    res->destination = destination;

    return res;
}

/* Accesseur : renvoie l'origine de l'arête. */
Point* getOrigin(const DEdge* DE) {
    assert(DE);
    return DE->origin;
}

/* Accesseur : renvoie la destination de l'arête. */
Point* getDestination(const DEdge* DE) {
    assert(DE);
    return DE->destination;
}

/* Affiche une arête sous la forme "[ (x1,y1) -> (x2,y2) ]". */
void viewDEdge(const void* DE) {
    assert(DE);
    const DEdge* e = (const DEdge*)DE;
    printf("[ ");
    viewPoint(e->origin);
    printf(" -> ");
    viewPoint(e->destination);
    printf(" ]");
}

/* Libère la mémoire associée à l'arête.
 * Important : on ne libère PAS origin/destination ici, car ils
 * appartiennent généralement à une structure globale (tableau de points).
 * (Sinon risque de double free.) */
void freeDEdge(void* DE) {
    if (DE != NULL)
        free(DE);
}
